
package school.management.system;

/**
 *
 * @author RakaKamara
 */


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author RakaKamara
 */
public class Student_Registration extends JFrame implements ActionListener{
     JTable table;
     JScrollPane scroll;
     DefaultTableModel model;
     Container c;
     JLabel titleLabel, fnLabel, lnLabel, phoneLabel, gpaLabel;
     JTextField fnTf, lnTf, phoneTf, gpaTf;
     JButton addButton, updateButton, deleteButton, clearButton;
    
     String[] columns = {"First name", "Last name", "Phone number", "GPA"};
     String[] rows = new String[4];
    Student_Registration(){
        initComponents();
    }
    public void initComponents(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(780, 690);
        this.setLocationRelativeTo(null);
        this.setTitle("Student Table");
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.lightGray);
        
        Font font = new Font("Arial", Font.BOLD, 16);
        
        titleLabel = new JLabel("Student Registration");
        titleLabel.setFont(font);
        titleLabel.setBounds(140, 10, 250, 50);
        c.add(titleLabel);
        
        fnLabel = new JLabel("First name    ");
        fnLabel.setBounds(10, 80, 140, 30);
        fnLabel.setFont(font);
        c.add(fnLabel);
        
        fnTf = new JTextField();
        fnTf.setBounds(110, 80, 200, 30);
        fnTf.setFont(font);
        c.add(fnTf);
        
        addButton = new JButton("Add");
        addButton.setBounds(400, 80, 100, 30);
        addButton.setFont(font);
        c.add(addButton);
        
        lnLabel = new JLabel("Last name    ");
        lnLabel.setBounds(10, 130, 150, 30);
        lnLabel.setFont(font);
        c.add(lnLabel);
        
        lnTf = new JTextField();
        lnTf.setBounds(110, 130, 200, 30);
        lnTf.setFont(font);
        c.add(lnTf);
        
        updateButton = new JButton("Update");
        updateButton.setBounds(400, 130, 100, 30);
        updateButton.setFont(font);
        c.add(updateButton);
        
        phoneLabel = new JLabel("Phone    ");
        phoneLabel.setBounds(10, 180, 150, 30);
        phoneLabel.setFont(font);
        c.add(phoneLabel);
        
        phoneTf = new JTextField();
        phoneTf.setBounds(110, 180, 200, 30);
        phoneTf.setFont(font);
        c.add(phoneTf);
        
        deleteButton = new JButton("Delete");
        deleteButton.setBounds(400, 180, 100, 30);
        deleteButton.setFont(font);
        c.add(deleteButton);
        
        gpaLabel = new JLabel("GPA    ");
        gpaLabel.setBounds(10, 230, 150, 30);
        gpaLabel.setFont(font);
        c.add(gpaLabel);
        
        gpaTf = new JTextField();
        gpaTf.setBounds(110, 230, 200, 30);
        gpaTf.setFont(font);
        c.add(gpaTf);
        
        clearButton = new JButton("Clear  ");
        clearButton.setBounds(400, 230, 100, 30);
        clearButton.setFont(font);
        c.add(clearButton);
        
        table = new JTable();
        
        model = new DefaultTableModel();
        model.setColumnIdentifiers(columns);
        table.setModel(model);
        table.setFont(font);
        table.setSelectionBackground(Color.GREEN);
        table.setRowHeight(30);
        
        scroll = new JScrollPane(table);
        scroll.setBounds(10, 360, 740, 265);
        c.add(scroll);
        
        
        addButton.addActionListener(this);        
        updateButton.addActionListener(this);
        clearButton.addActionListener(this);
        deleteButton.addActionListener(this);
        
        table.addMouseListener(new MouseAdapter(){
            
            public void mouseClicked(MouseEvent me){
                int numberOfRow = table.getSelectedRow();
                
                String f_name = model.getValueAt(numberOfRow, 0).toString();
                String l_name = model.getValueAt(numberOfRow, 1).toString();
                String phone = model.getValueAt(numberOfRow, 2).toString();
                String gpa = model.getValueAt(numberOfRow, 3).toString();
                
                fnTf.setText(f_name);
                lnTf.setText(l_name);
                phoneTf.setText(phone);
                gpaTf.setText(gpa);
            }
    });
        
        
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource() == addButton){
           rows[0] = fnTf.getText();
           rows[1] = lnTf.getText();
           rows[2] = phoneTf.getText();
           rows[3] = gpaTf.getText();
           model.addRow(rows);
        }
        
        else if(ae.getSource() == clearButton){
            fnTf.setText(null);
            lnTf.setText(null);
            phoneTf.setText(null);
            gpaTf.setText(null);
        }
        else if(ae.getSource() == deleteButton){
           int numberOfRow = table.getSelectedRow();
           if(numberOfRow >= 0){
               model.removeRow(numberOfRow);
           }
           else{
               JOptionPane.showMessageDialog(null, "No row exists");
           }
        }
        else if(ae.getSource() == updateButton){
           int numberOfRow = table.getSelectedRow();
           String f_name = fnTf.getText();
           String l_name = lnTf.getText();
           String phone = phoneTf.getText();
           String gpa = gpaTf.getText();
           
           model.setValueAt(f_name, numberOfRow, 0);
           model.setValueAt(l_name, numberOfRow, 1);
           model.setValueAt(phone, numberOfRow, 2);
        }
    }
    public static void main(String[] args) {
      Student_Registration frame = new Student_Registration();
      frame.setVisible(true);
    }

    
}


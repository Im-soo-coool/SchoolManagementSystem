
package school.management.system;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


/**
 *
 * @author RakaKamara
 */
 public class Home extends JFrame implements ActionListener{

    JFrame f;
    JMenu menu, teacher, student, exit, exam, course, payments, Student_Registration;
    JMenuItem i1, i2, i3, i4, i5, i6, i7, i8, i9;
    
    JMenuItem l1, l2, l3, s1, s2, s3;
    
    
    Home(){
          f = new JFrame("School Management");  
          JMenuBar mb = new JMenuBar(); 
          
          menu = new JMenu("Home");  
          mb.add(menu);
          
          student = new JMenu("Student");   
          teacher = new JMenu("Teacher");
          exam = new JMenu("Exam");
          course = new JMenu("Show Courses");
          exit = new JMenu("Exit");
          payments = new JMenu("Payment List");
          Student_Registration = new JMenu("Student Registration");
         
          menu.add(teacher); menu.add(student); menu.add(exam); menu.add(course); menu.add(payments); menu.add(Student_Registration); menu.add(exit); 
           
          l1 = new JMenuItem("EngLish Department");
          l2 = new JMenuItem("Bangla Department"); 
          l3 = new JMenuItem("Math Department");
          
          
          i3 = new JMenuItem("Student List of Class One");
          i1 = new JMenuItem("Student List of Class Two");
          i6 = new JMenuItem("Student List of Class Three");
          i7 = new JMenuItem("Student List of Class Four");
          i8 = new JMenuItem("Student List of Class Five");
           
           
          i2 = new JMenuItem("Item 3");           
          i5 = new JMenuItem("Take the quiz");
          s1 = new JMenuItem("Courses");
          s2 = new JMenuItem("Show Payments");
          s3 = new JMenuItem("Student Registration");
          i4 = new JMenuItem("Exit");
          
          
          
          teacher.add(l1);
          teacher.add(l2);
          teacher.add(l3);
          
          student.add(i3);
          student.add(i1);
          student.add(i6); 
          student.add(i7);
          student.add(i8);
          Student_Registration.add(s3);
                  
          exam.add(i5);
          course.add(s1);
          payments.add(s2);
          exit.add(i4);
         
          
          f.setJMenuBar(mb);  
          f.setSize(400,400);  
          f.setLayout(null);  
          f.setVisible(true);
          
          
          i3.addActionListener(this);
          l1.addActionListener(this);
          l2.addActionListener(this);
          l3.addActionListener(this);
          i1.addActionListener(this);
          i4.addActionListener(this);
          i5.addActionListener(this);
          i6.addActionListener(this);
          i7.addActionListener(this);
          i8.addActionListener(this);
          s1.addActionListener(this);
          s3.addActionListener(this);
          s2.addActionListener(this);
          
          
}  

    @Override
    public void actionPerformed(ActionEvent ae) {
      
        if(ae.getSource() == l1){
            new TeacherList();
        }
        
         if(ae.getSource() == l2){
            new TeacherList1();
        }
        
         if(ae.getSource() == l3){
            new TeacherList2();
        }
         
        if(ae.getSource() == i3){
          new StudentList1();  
        } 
         if(ae.getSource() == i1){
          new StudentList();  
        } 
          
          if(ae.getSource() == i6){
          new StudentList2();  
        } 
           if(ae.getSource() == i7){
          new StudentList3();  
        } 
            if(ae.getSource() == i8){
          new StudentList4();  
        } 
          if(ae.getSource() == i5){
             new Exam();
        }
          
          if(ae.getSource() == s1){
            new ShowCourses();
        }
          
          if(ae.getSource() == s2){
            new Payments();
        }
          
          if(ae.getSource() == s3){
            Student_Registration frame = new Student_Registration();
            frame.setVisible(true);
        }
          
         if(ae.getSource() == i4){
            System.exit(0);
        }
          
        
    }
          

     public static void main(String[] args) {
         new Home();
     }
}

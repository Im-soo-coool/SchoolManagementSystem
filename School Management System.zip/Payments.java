
package school.management.system;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author RakaKamara
 */
public class Payments extends JFrame implements ActionListener{
   JLabel l; 
   JCheckBox cb1, cb2, cb3, cb4, cb5;
   JButton b;
   Payments(){
       l = new JLabel("School Payment");
       l.setBounds(50,50,300,20);
       
       cb1 = new JCheckBox("School fees = 2500 Tk");
       cb1.setBounds(100,100,150,20);
       
       cb2 = new JCheckBox("Lab fees = 500 Tk");
       cb2.setBounds(100,150,150,20);
       
       cb3 = new JCheckBox("Bus Hire(optional) = 500 Tk");
       cb3.setBounds(100,200,350,20);
       
       cb4 = new JCheckBox("Student Activity fees = 250 Tk");
       cb4.setBounds(100,250,300,20);
       
       cb5 = new JCheckBox("Uniform(optional) = 1000 Tk");
       cb5.setBounds(100,300, 300,20);
       
       b = new JButton("Total");
       b.setBounds(100,400,80,30);      
       b.addActionListener(this);  
       
        add(l);add(cb1);add(cb2);add(cb3);add(cb4);add(cb5);add(b);
        setSize(500,500);  
        setLayout(null);  
        setVisible(true);  
        //setDefaultCloseOperation(EXIT_ON_CLOSE); 
        
       
   }

    @Override
    public void actionPerformed(ActionEvent ae) {
        float amount=0;  
        String msg=""; 
       if(cb1.isSelected()){  
            amount+=2500;  
            msg="School fees: 2500\n";  
        }  
       if(cb2.isSelected()){  
            amount+=500;  
            msg="Lab fees: 500\n";  
        }
       if(cb3.isSelected()){  
            amount+=500;  
            msg="Bus Hire: 500\n";  
        }  
       if(cb4.isSelected()){  
            amount+=250;  
            msg="Student Activity fees: 250\n";  
        }  
       if(cb5.isSelected()){  
            amount+=1000;  
            msg="Uniform: 1000\n";  
        }
       msg+="-----------------\n";  
        JOptionPane.showMessageDialog(this,msg+"Total: "+amount);  
    }
    public static void main(String[] args) {
        new  Payments();
    }
}


package school.management.system;

import javax.swing.*;

/**
 *
 * @author RakaKamara
 */
public class StudentList {
      
    JFrame f1;    
    StudentList(){    
    f1 = new JFrame();    
    String data[][]={ {"101","Amit"},    
                          {"102","Jai"},    
                          {"103","Sachin"},
                          {"104", "Raka"},
                          {"105", "Kamara"},
                          {"106", "Aamal"},
                          {"107", "Soul"},
                          {"108", "Wali"},
                          {"109", "King"},
                          {"110", "Amar"},
                          {"111", "Meri"},
                          {"112","Sachin"},
                          {"113", "Raka"},
                          {"114", "Kamara"},
                          {"115", "Aamal"},
                          {"116", "Soul"},
                          {"117", "Wali"},
                          {"118", "King"},
                          {"119", "Amar"},
                          {"120", "Meri"},
                          {"121","Sachin"},
                          {"122", "Raka"},
                          {"123", "Kamara"},
                          {"124", "Aamal"},
                          {"125", "Soul"},
                          {"126", "Wali"},
                          {"127", "King"},
                          {"128", "Amar"},
                          {"129", "Meri"},
                          {"130", "Meri"},
                          
    };    
    String column[]={"ID","NAME"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f1.add(sp);          
    f1.setSize(300,400);    
    f1.setVisible(true);    
}    
}  

class StudentList1 {
      
    JFrame f1;    
    StudentList1(){    
    f1 = new JFrame();    
    String data[][]={ {"101","Amit"},    
                          {"102","Jai"},    
                          {"103","Sachin"},
                          {"104", "Raka"},
                          {"105", "Kamara"},
                          {"106", "Aamal"},
                          {"107", "Soul"},
                          {"108", "Wali"},
                          {"109", "King"},
                          {"110", "Amar"},
                          {"111", "Meri"},
                          {"112","Sachin"},
                          {"113", "Raka"},
                          {"114", "Kamara"},
                          {"115", "Aamal"},
                          {"116", "Soul"},
                          {"117", "Wali"},
                          {"118", "King"},
                          {"119", "Amar"},
                          {"120", "Meri"},
                          {"121","Sachin"},
                          {"122", "Raka"},
                          {"123", "Kamara"},
                          {"124", "Aamal"},
                          {"125", "Soul"},
                          {"126", "Wali"},
                          {"127", "King"},
                          {"128", "Amar"},
                          {"129", "Meri"},
                          {"130", "Meri"},
                          
    };    
    String column[]={"ID","NAME"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f1.add(sp);          
    f1.setSize(300,400);    
    f1.setVisible(true);    
}    
}  
class StudentList2 {
      
    JFrame f1;    
    StudentList2(){    
    f1 = new JFrame();    
    String data[][]={ {"101","Amit"},    
                          {"102","Jai"},    
                          {"103","Sachin"},
                          {"104", "Raka"},
                          {"105", "Kamara"},
                          {"106", "Aamal"},
                          {"107", "Soul"},
                          {"108", "Wali"},
                          {"109", "King"},
                          {"110", "Amar"},
                          {"111", "Meri"},
                          {"112","Sachin"},
                          {"113", "Raka"},
                          {"114", "Kamara"},
                          {"115", "Aamal"},
                          {"116", "Soul"},
                          {"117", "Wali"},
                          {"118", "King"},
                          {"119", "Amar"},
                          {"120", "Meri"},
                          {"121","Sachin"},
                          {"122", "Raka"},
                          {"123", "Kamara"},
                          {"124", "Aamal"},
                          {"125", "Soul"},
                          {"126", "Wali"},
                          {"127", "King"},
                          {"128", "Amar"},
                          {"129", "Meri"},
                          {"130", "Meri"},
                          
    };    
    String column[]={"ID","NAME"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f1.add(sp);          
    f1.setSize(300,400);    
    f1.setVisible(true);    
}    
}  
class StudentList3 {
      
    JFrame f1;    
    StudentList3(){    
    f1 = new JFrame();    
    String data[][]={ {"101","Amit"},    
                          {"102","Jai"},    
                          {"103","Sachin"},
                          {"104", "Raka"},
                          {"105", "Kamara"},
                          {"106", "Aamal"},
                          {"107", "Soul"},
                          {"108", "Wali"},
                          {"109", "King"},
                          {"110", "Amar"},
                          {"111", "Meri"},
                          {"112","Sachin"},
                          {"113", "Raka"},
                          {"114", "Kamara"},
                          {"115", "Aamal"},
                          {"116", "Soul"},
                          {"117", "Wali"},
                          {"118", "King"},
                          {"119", "Amar"},
                          {"120", "Meri"},
                          {"121","Sachin"},
                          {"122", "Raka"},
                          {"123", "Kamara"},
                          {"124", "Aamal"},
                          {"125", "Soul"},
                          {"126", "Wali"},
                          {"127", "King"},
                          {"128", "Amar"},
                          {"129", "Meri"},
                          {"130", "Meri"},
                          
    };    
    String column[]={"ID","NAME"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f1.add(sp);          
    f1.setSize(300,400);    
    f1.setVisible(true);    
}    
}  
class StudentList4 {
      
    JFrame f1;    
    StudentList4(){    
    f1 = new JFrame();    
    String data[][]={ {"101","Amit"},    
                          {"102","Jai"},    
                          {"103","Sachin"},
                          {"104", "Raka"},
                          {"105", "Kamara"},
                          {"106", "Aamal"},
                          {"107", "Soul"},
                          {"108", "Wali"},
                          {"109", "King"},
                          {"110", "Amar"},
                          {"111", "Meri"},
                          {"112","Sachin"},
                          {"113", "Raka"},
                          {"114", "Kamara"},
                          {"115", "Aamal"},
                          {"116", "Soul"},
                          {"117", "Wali"},
                          {"118", "King"},
                          {"119", "Amar"},
                          {"120", "Meri"},
                          {"121","Sachin"},
                          {"122", "Raka"},
                          {"123", "Kamara"},
                          {"124", "Aamal"},
                          {"125", "Soul"},
                          {"126", "Wali"},
                          {"127", "King"},
                          {"128", "Amar"},
                          {"129", "Meri"},
                          {"130", "Meri"},
                          
    };    
    String column[]={"ID","NAME"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f1.add(sp);          
    f1.setSize(300,400);    
    f1.setVisible(true);    
}    
}  



package school.management.system;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author RakaKamara
 */
public class Login {
     public static void main(String[] args) {    
    JFrame f = new JFrame("Login"); 
    
    final JTextField tx = new JTextField();
    tx.setBounds(30, 30, 200, 30);
    tx.setText("  __WELCOME TO XY SCHOOL__");
            
            
     final JLabel label = new JLabel();            
     label.setBounds(20,150, 200,50); 
     
     final JPasswordField value = new JPasswordField();   
     value.setBounds(100,130,100,30); 
     
     JLabel l1=new JLabel("Username:");    
        l1.setBounds(20,80, 80,30); 
        
        JLabel l2=new JLabel("Password:");    
        l2.setBounds(20, 130, 80,30); 
        
        JButton b = new JButton("Login");  
        b.setBounds(100, 180, 80,30);   
        
        final JTextField text = new JTextField();  
        text.setBounds(100, 80, 100, 30);
        
        
                f.add(tx);
                f.add(value); f.add(l1); f.add(label); f.add(l2); f.add(b); f.add(text);  
                f.setSize(400,400);    
                f.setLayout(null);    
                f.setVisible(true);     
                b.addActionListener(new ActionListener() { 
                    
                public void actionPerformed(ActionEvent e) { 
                   try{
                    File file = new File("C:\\Users\\illusion\\Desktop\\School\\Login.txt");
                    Scanner in = new Scanner(file);
                    
                    String Username = in.nextLine();
                    String Password = in.nextLine();
                    
                    if(Username.equals(text.getText()) &&   Password.equals(new String(value.getPassword()))){
                        System.out.println(Username);
                        System.out.println(Password);
                        
                        System.out.println("Successfully logged in");
                       
                      
                        f.setVisible(false);
                        
                        Home home = new Home();
                        home.setVisible(true);
                   }else{
                        System.out.println("Invalid Information! :( Try again");
                    }
                    
                   
                   }catch(FileNotFoundException ex){
                       
                   }
                }  
             });   
}  
}  




package school.management.system;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author RakaKamara
 */
 class TeacherList {
    JFrame f2;
        TeacherList(){
        f2 = new JFrame();    
    String data[][]={ {"Rashida Akhter","01573844"},
        {"Sanjida Akhter","01573844"},
        {"Momotaz Akhter","01573844"},
        {"Anamul Haque","01573844"},
        {"Zahurul Haque","01573844"},
        {"Ohidul Haque","01573844"},
        {"Tobaroq Ali","01573844"},
        {"Alex Lee","01573844"},
    };    
    String column[]={"NAME", "Phone"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f2.add(sp);          
    f2.setSize(300,400);    
    f2.setVisible(true);
        }
        
}
        class TeacherList1 {
        JFrame f2;
        TeacherList1(){
        f2 = new JFrame();    
        String data[][]={ {"Wali Ahmed","0173844"},
        {"Soul Akhter","01673844"},
        {"Anamul Haque","0183844"},
        {"Zahurul Haque","01573844"},
        {"Ohidul Haque","01573844"},
        {"Tobaroq Ali","01573844"},
        {"Alex Lee","01573844"},
    };    
    String column[]={"NAME", "Phone"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f2.add(sp);          
    f2.setSize(300,400);    
    f2.setVisible(true);
        }
  }
class TeacherList2 {
        JFrame f2;
        TeacherList2(){
        f2 = new JFrame();    
        String data[][]={ {"Dua Begum","0173844"},
        {"Mariyum Akhter","01673844"},
        {"Anamul Haque","0183844"},
        {"Zahurul Haque","01573844"},
        {"Ohidul Haque","01573844"},
        {"Fatima Begum","01573844"},
        {"Alex Lee","01573844"},
    };    
    String column[]={"NAME", "Phone"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f2.add(sp);          
    f2.setSize(300,400);    
    f2.setVisible(true);
        }
  }
